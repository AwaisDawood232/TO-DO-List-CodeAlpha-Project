




// Create a "close" button and append it to each list item
let myList = document.getElementsByTagName("li");

let i = 0;
for (let i = 0; i < myList.length; i++) {
    let trashIcon = document.createElement("i");
    trashIcon.className = "close fa-solid fa-trash";
    myList[i].appendChild(trashIcon);
}

// Click on a close button to hide the current list item
let close = document.getElementsByClassName("close");
for (let j = 0; j < close.length; j++) {
    close[i].onclick = function() {
        let div = this.parentElement;
        div.style.display = "none";
    }
}

// when user clicked on item to check
let list = document.querySelector('ul');
list.addEventListener('click', function(event) {
  if (event.target.tagName === 'LI') {
    event.target.classList.toggle('checked');
  }
}, false);


// Create a new list item when clicking on the "Add" button

function newItem() {
    let userInput = document.getElementById("user_input").value;
    let li = document.createElement("li");
    
    // below text variable store the user input value
    let userText = document.createTextNode(userInput); 
    li.appendChild(userText);
    // now we use condition if user didn't write anything in the input field
    if(userInput === " " || userInput === ""){
        alert("You must write something!");
    }else{
        document.getElementById("myUl").appendChild(li);        
    }
    document.getElementById("user_input").value = "";

   
    let trashIcon = document.createElement("i");
    trashIcon.className = "close fa-solid fa-trash";
    li.appendChild(trashIcon);
    

    trashIcon.onclick = function() {
        let listItem = this.parentElement;
        listItem.style.display = "none";
      }

}    
